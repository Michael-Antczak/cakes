import React from 'react'
import ListCake from '../components/ListCake.js';

const Home = () => (
    <ListCake  />    
)

export default Home;