import React from 'react'
import AddCake from '../components/AddCake.js';

const Home = () => (
    <AddCake  />    
)

export default Home;